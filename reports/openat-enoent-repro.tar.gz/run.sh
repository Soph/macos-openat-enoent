#!/bin/sh
# Build and run every probe. Needs only cc. Writes only to $TMPDIR.
set -e
cd "$(dirname "$0")"
echo "macOS $(sw_vers -productVersion) ($(sw_vers -buildVersion)), $(uname -m), $(sysctl -n hw.ncpu) cores"
echo "$(uname -v)"
echo
for p in openat_race other_syscalls failclosed processes; do
    cc -O2 -pthread -std=gnu11 -o "/tmp/$p.probe" "$p.c"
done
echo "############ openat_race: the finding, with five controls ############"
"/tmp/openat_race.probe" 20 200 || true
echo
echo "############ other_syscalls: is it isolated to one call? ############"
"/tmp/other_syscalls.probe" 20 200 || true
echo
echo "############ processes: does it survive across processes? ############"
"/tmp/processes.probe" 20 100 || true
echo
echo "############ failclosed: is it fail-closed? ############"
"/tmp/failclosed.probe" 20 200 || true
